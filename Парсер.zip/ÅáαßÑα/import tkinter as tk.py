import io
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import json
from urllib.request import urlopen
from PIL import Image, ImageTk

with open('data.json.json', 'r', encoding='utf-8') as file:
    products = json.load(file)

root = tk.Tk()
root.title("Product List")
root.geometry("800x600")

list_frame = ttk.Frame(root)
list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

details_frame = ttk.Frame(root)
details_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

scrollbar = ttk.Scrollbar(list_frame)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

product_list = tk.Listbox(list_frame, yscrollcommand=scrollbar.set)
product_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
scrollbar.config(command=product_list.yview)

for product in products:
    product_list.insert(tk.END, product['title'])

title_label = ttk.Label(details_frame, text="Title:")
title_value = ttk.Label(details_frame, text="")
price_label = ttk.Label(details_frame, text="Price:")
price_value = ttk.Label(details_frame, text="")
photo_label = ttk.Label(details_frame)
photo_value = ttk.Label(details_frame)
specs_label = ttk.Label(details_frame, text="Specifications:")

title_label.grid(row=0, column=0, sticky=tk.W)
title_value.grid(row=0, column=1, sticky=tk.W)
price_label.grid(row=1, column=0, sticky=tk.W)
price_value.grid(row=1, column=1, sticky=tk.W)
photo_label.grid(row=2, column=0, columnspan=2)
photo_value.grid(row=3, column=0, columnspan=2)
specs_label.grid(row=4, column=0, columnspan=2, sticky=tk.W)

def show_product_details(event):
    selected_index = product_list.curselection()[0]
    selected_product = products[selected_index]
    
    title_value.config(text=selected_product.get('title', 'N/A'))
    price_value.config(text=selected_product.get('price', 'N/A'))

    image_url = selected_product.get('photoUrl')
    if image_url:
        image_byt = urlopen(image_url).read()
        image_b64 = Image.open(io.BytesIO(image_byt))
        photo = ImageTk.PhotoImage(image_b64)
        photo_label.config(image=photo)
        photo_label.image = photo

    specs_text = ""
    for key, value in selected_product.items():
        if key not in ['title', 'price', 'photoUrl']:
            specs_text += f"{key}: {value}\n"
    specs_label.config(text=specs_text)

product_list.bind('<<ListboxSelect>>', show_product_details)

root.mainloop()
